const BASE_URL = "https://ivasms.com/api";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  Accept: "application/json, text/plain, */*",
  "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
  "Cache-Control": "no-cache",
  Pragma: "no-cache",
  Referer: "https://ivasms.com/portal/sr",
};

function getToken(): string {
  const token = process.env["IVASMS_API_KEY"];
  if (!token) throw new Error("IVASMS_API_KEY not set");
  return token;
}

async function apiGet(endpoint: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE_URL}/${endpoint}`);
  url.searchParams.set("token", getToken());
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v);
  }

  const res = await fetch(url.toString(), { headers: HEADERS });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} من ivasms`);
  }

  const text = await res.text();
  return text.trim();
}

export interface IvaNumber {
  id: string;
  phone: string;
}

export async function getBalance(): Promise<string> {
  const raw = await apiGet("get_balance");
  return raw;
}

export async function getNumber(service = "wa", country = "0"): Promise<IvaNumber> {
  const raw = await apiGet("get_number", { service, country });
  if (raw.startsWith("ERROR")) throw new Error(translateError(raw));
  const parts = raw.split(":");
  if (parts.length < 2) throw new Error(`استجابة غير متوقعة: ${raw}`);
  const id = parts[0]!.trim();
  const phone = parts.slice(1).join(":").trim();
  return { id, phone };
}

export async function getSms(id: string): Promise<string | null> {
  const raw = await apiGet("get_sms", { id });

  if (
    raw === "STATUS_WAIT_CODE" ||
    raw === "STATUS_WAIT_RETRY" ||
    raw === "STATUS_WAIT_RESEND"
  ) {
    return null;
  }
  if (raw.startsWith("STATUS_OK:")) {
    return raw.replace("STATUS_OK:", "").trim();
  }
  if (raw === "STATUS_CANCEL") {
    throw new Error("تم إلغاء الطلب");
  }
  if (raw.startsWith("ERROR")) {
    throw new Error(translateError(raw));
  }
  return raw;
}

export async function cancelOrder(id: string): Promise<string> {
  const raw = await apiGet("cancel", { id });
  return raw;
}

function translateError(raw: string): string {
  const map: Record<string, string> = {
    ERROR_NO_NUMBERS: "لا توجد أرقام متاحة حالياً، حاول لاحقاً",
    ERROR_NO_BALANCE: "رصيدك غير كافٍ في ivasms",
    ERROR_BAD_SERVICE: "الخدمة غير متاحة",
    ERROR_BAD_KEY: "مفتاح API غير صحيح — تحقق من IVASMS_API_KEY",
    ERROR_WRONG_ACTIVATION_ID: "رقم الطلب غير موجود",
    ERROR_BAD_ACTION: "إجراء غير صحيح",
    ERROR_BANNED: "الحساب محظور في ivasms",
  };
  return map[raw] ?? raw;
}
