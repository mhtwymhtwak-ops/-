import { Telegraf, Context } from "telegraf";
import { logger } from "../lib/logger";
import {
  getBalance,
  getNumber,
  getSms,
  cancelOrder,
} from "./ivasms";

const ADMIN_ID = process.env["TELEGRAM_ADMIN_ID"];
const BOT_TOKEN = process.env["TELEGRAM_BOT_TOKEN"];

if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN not set");

const bot = new Telegraf(BOT_TOKEN);

const pendingPolls = new Map<string, ReturnType<typeof setInterval>>();

function isAdmin(ctx: Context): boolean {
  const userId = ctx.from?.id?.toString();
  if (ADMIN_ID && userId !== ADMIN_ID) {
    ctx.reply("⛔ غير مصرح لك باستخدام هذا البوت.").catch(() => {});
    return false;
  }
  return true;
}

function startPolling(ctx: Context, orderId: string) {
  let attempts = 0;
  const maxAttempts = 60;

  const interval = setInterval(async () => {
    attempts++;
    try {
      const code = await getSms(orderId);
      if (code) {
        clearInterval(interval);
        pendingPolls.delete(orderId);
        await ctx.reply(
          `✅ *تم استقبال الكود!*\n\n` +
          `🔑 *الكود:* \`${code}\`\n` +
          `🆔 *رقم الطلب:* \`${orderId}\``,
          { parse_mode: "Markdown" }
        );
      } else if (attempts >= maxAttempts) {
        clearInterval(interval);
        pendingPolls.delete(orderId);
        await ctx.reply(
          `⏰ انتهت مهلة الانتظار للطلب \`${orderId}\`.\nاستخدم /cancel\_${orderId} لإلغاء الطلب.`,
          { parse_mode: "Markdown" }
        );
      }
    } catch (err) {
      clearInterval(interval);
      pendingPolls.delete(orderId);
      const msg = err instanceof Error ? err.message : String(err);
      await ctx.reply(`❌ خطأ أثناء انتظار الكود: ${msg}`).catch(() => {});
    }
  }, 5000);

  pendingPolls.set(orderId, interval);
}

bot.start((ctx) => {
  if (!isAdmin(ctx)) return;
  ctx.reply(
    `👋 *أهلاً! بوت ivasms للواتساب*\n\n` +
    `الأوامر المتاحة:\n\n` +
    `🔢 /getnum — احصل على رقم واتساب جديد\n` +
    `💰 /balance — تحقق من رصيدك\n` +
    `📩 /code \`[id]\` — تحقق يدوياً من الكود\n` +
    `❌ /cancel \`[id]\` — إلغاء طلب\n` +
    `ℹ️ /help — عرض المساعدة`,
    { parse_mode: "Markdown" }
  );
});

bot.help((ctx) => {
  if (!isAdmin(ctx)) return;
  ctx.reply(
    `📖 *المساعدة*\n\n` +
    `• /getnum — يطلب رقم جديد من ivasms لواتساب تلقائياً ويبدأ الانتظار للكود\n` +
    `• /balance — يعرض رصيدك الحالي على ivasms\n` +
    `• /code [id] — تحقق يدوياً من كود الطلب المحدد\n` +
    `• /cancel [id] — إلغاء الطلب وتحرير الرقم\n\n` +
    `⚡ عند طلب رقم، البوت ينتظر الكود تلقائياً لمدة 5 دقائق.`,
    { parse_mode: "Markdown" }
  );
});

bot.command("balance", async (ctx) => {
  if (!isAdmin(ctx)) return;
  try {
    const bal = await getBalance();
    ctx.reply(`💰 *رصيدك الحالي:* \`${bal}\``, { parse_mode: "Markdown" });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    ctx.reply(`❌ فشل تحميل الرصيد: ${msg}`);
  }
});

bot.command("getnum", async (ctx) => {
  if (!isAdmin(ctx)) return;
  const waitMsg = await ctx.reply("⏳ جاري طلب رقم واتساب من ivasms...");
  try {
    const { id, phone } = await getNumber("wa", "0");
    await ctx.telegram.editMessageText(
      waitMsg.chat.id,
      waitMsg.message_id,
      undefined,
      `✅ *تم الحصول على الرقم!*\n\n` +
      `📱 *الرقم:* \`${phone}\`\n` +
      `🆔 *رقم الطلب:* \`${id}\`\n\n` +
      `⏳ البوت ينتظر كود واتساب تلقائياً (5 دقائق)...\n` +
      `الآن افتح واتساب وأدخل هذا الرقم للتحقق.`,
      { parse_mode: "Markdown" }
    );
    startPolling(ctx, id);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await ctx.telegram.editMessageText(
      waitMsg.chat.id,
      waitMsg.message_id,
      undefined,
      `❌ فشل طلب الرقم: ${msg}`
    );
  }
});

bot.command("code", async (ctx) => {
  if (!isAdmin(ctx)) return;
  const parts = ctx.message.text.split(" ");
  const id = parts[1];
  if (!id) {
    ctx.reply("⚠️ استخدم الأمر هكذا: /code [رقم الطلب]");
    return;
  }
  try {
    const code = await getSms(id);
    if (code) {
      ctx.reply(`✅ *الكود:* \`${code}\``, { parse_mode: "Markdown" });
    } else {
      ctx.reply(`⏳ الكود لم يصل بعد للطلب \`${id}\`، حاول مرة أخرى.`, {
        parse_mode: "Markdown",
      });
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    ctx.reply(`❌ خطأ: ${msg}`);
  }
});

bot.command("cancel", async (ctx) => {
  if (!isAdmin(ctx)) return;
  const parts = ctx.message.text.split(" ");
  const id = parts[1];
  if (!id) {
    ctx.reply("⚠️ استخدم الأمر هكذا: /cancel [رقم الطلب]");
    return;
  }
  const poll = pendingPolls.get(id);
  if (poll) {
    clearInterval(poll);
    pendingPolls.delete(id);
  }
  try {
    const result = await cancelOrder(id);
    ctx.reply(`🗑️ تم إلغاء الطلب \`${id}\`: ${result}`, {
      parse_mode: "Markdown",
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    ctx.reply(`❌ فشل الإلغاء: ${msg}`);
  }
});

bot.on("message", (ctx) => {
  if (!isAdmin(ctx)) return;
  ctx.reply("❓ أمر غير معروف. استخدم /help لعرض الأوامر.");
});

bot.catch((err) => {
  logger.error({ err }, "Telegram bot error");
});

export function startBot() {
  bot.launch({ dropPendingUpdates: true });
  logger.info("Telegram bot started (polling)");

  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
}
